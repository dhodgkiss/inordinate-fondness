+++
author = ""
categories = [""]
date = ""
description = ""
featured = ""
featuredalt = ""
featuredpath = ""
link = ""
linktitle = ""
format = ""
title = ""
type = "itemized"

+++
